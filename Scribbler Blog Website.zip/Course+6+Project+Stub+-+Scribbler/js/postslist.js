
const deleteButtons = document.querySelectorAll('.delete');
const deleteModal = document.querySelector('.modal');
const btnYes = document.querySelector('.deletebtn');
const btnNo = document.querySelector('.canclebtn');

let postToDelete;

deleteButtons.forEach((button, index) => {
    button.addEventListener('click', () => {
        postToDelete = index;
        deleteModal.style.display = 'block';
    });
});

btnYes.addEventListener('click', () => {
    if (typeof postToDelete !== 'undefined') {
        const postElements = document.querySelectorAll('.post');
        postElements[postToDelete].remove();
    }
    deleteModal.style.display = 'none';
    postToDelete = undefined;
});

btnNo.addEventListener('click', () => {
    deleteModal.style.display = 'none';
    postToDelete = undefined;
});
