// Get the modal
var modal = document.getElementById('sing');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}

const deleteButtons = document.querySelectorAll('.delete');
const deleteModal = document.querySelector('.modal');
const btnYes = document.querySelector('.deletebtn');
const btnNo = document.querySelector('.canclebtn');

let postToDelete;

deleteButtons.forEach((button, index) => {
    button.addEventListener('click', () => {
        postToDelete = index;
        deleteModal.style.display = 'block';
    });
});