const editButton = document.getElementById('editButton');
const titleElement = document.getElementById('title');
const articalElement = document.getElementById('artical');

editButton.addEventListener('click', () => {
    // Toggle between edit and save modes
    if (editButton.textContent === 'Edit ') {
        editButton.textContent = 'Save';
        titleElement.contentEditable = true;
        articalElement.contentEditable = true;
        titleElement.style.border = '2px solid red';
        articalElement.style.border = '2px solid red';
    } else {
        editButton.textContent = 'Edit';
        titleElement.contentEditable = false;
        articalElement.contentEditable = false;
        titleElement.style.border = 'none';
        articalElement.style.border = 'none';
    }
});


//-- ----------------- for like button------------------- --

const likeButton = document.getElementById('likeButton');
const likeCount = document.getElementById('likeCount');

let likes = 0;

likeButton.addEventListener('click', () => {
    likes++;
    likeCount.textContent = likes === 1 ? '1 Like' : `${likes} person like this!`;
});

// for comment section 


        commentButton.addEventListener('click', () => {
            const commentText = commentInput.value;
            if (commentText.trim() !== '') {
                const commentDiv = document.createElement('div');
                commentDiv.classList.add('comment');
                commentDiv.textContent = commentText;

                allComments.insertBefore(commentDiv, allComments.firstChild);

                commentInput.value = ''; // Clear the input after adding the comment
            }
        });

